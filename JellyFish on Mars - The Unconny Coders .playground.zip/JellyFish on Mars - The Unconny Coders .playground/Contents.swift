import SwiftUI
import AVFoundation
import PlaygroundSupport

    struct story: View {
        var body:  some View {
            controller()
        }
    }
    PlaygroundPage.current.setLiveView(story())
     
