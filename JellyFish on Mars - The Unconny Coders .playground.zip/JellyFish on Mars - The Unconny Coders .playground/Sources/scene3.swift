import SwiftUI
import AVFoundation
import PlaygroundSupport


public struct scene3: View{
    @Binding var step: Int
    @State var introText = 1
    @State var animationCard = false
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "Aereoporto", withExtension: "m4a") {
        
            try! player = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
            player.numberOfLoops = -1 /// Number of times to loop the audio
            //self.audioPlayer?.play() /// start playing
            
            return player
                        
        } else {
                print("No audio file found")
        }
        
        return nil
        
    }()
        
    
    public init(_ step: Binding<Int>){
        self._step = step
    }
    
    public var body: some View{
        ZStack{
            Image(uiImage: UIImage(named: "Scena3.png")!)
                .resizable()
                .scaledToFill()
                .onAppear {
                    audioPlayer?.play()
                }
            //                .frame(width: 490, height: 700)
            ZStack{
                
                RoundedRectangle(cornerRadius: 50)
                    .fill(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                    .offset(x:60,y:30)
                
                RoundedRectangle(cornerRadius: 50)
                    .strokeBorder(LinearGradient(
                        gradient: Gradient(stops: [
                            .init(color: Color(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1)), location: 0),
                            .init(color: Color(#colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)), location: 1)]),
                        startPoint: UnitPoint(x: 0.5, y: -3.0616171314629196e-17),
                        endPoint: UnitPoint(x: 0.5, y: 0.9999999999999999)), lineWidth: 3)
                    .offset(x:60,y:30)
                
                if(introText == 1){
                    VStack{
                        
                        Text("When Jelly arrived at the airport, he found out that water wasn’t allowed on the plane, and he had remembered that he was composed of 98% water.")
                            .foregroundColor(Color.black)
                            .frame(width: 300)
                        //   con l'aggiunta di frame qui, il testo non va più sul bordo del rectangle ma l'animation del rectangle cosi fa solo il movimento sull asse y
                    }
                    .offset(x:60,y:30)
                }else{
                    VStack{
                        
                        Text("Jelly is so annoyed!   (Never a     joy for Jelly... 💩 !)")
                            .foregroundColor(Color.black)
                            .frame(width: 300)
                            .font(.system(size: 30, weight: .bold, design: .default))
                    }
                    .offset(x:60,y:30)
                }
                
                Button(action: {
                    if(introText < 2){
                        introText += 1
                    }
                    else{
                        step += 1
                    }
                }, label: {
                    Image(uiImage: UIImage(named: "Conchiglia.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                })
                    .offset(x:205,y:85)
            }
            .frame(width: animationCard ? 320 : 2, height: animationCard ? 150 : 2)
            .animation(.interactiveSpring(response: 1, dampingFraction: 1, blendDuration: 10))
            .onAppear {
                animationCard = true
            }
        }
        .frame(width:700,height:490)
    }
}
