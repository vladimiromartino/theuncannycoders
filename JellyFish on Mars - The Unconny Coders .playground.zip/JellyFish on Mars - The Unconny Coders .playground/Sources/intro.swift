import SwiftUI
import AVFoundation
import PlaygroundSupport



public struct intro: View {
    @Binding var step: Int
    
    @State var page = 1
    @State var introText = 1
    @State private var fadeInOut = false
    @State private var fadeInOut1 = false
    @State private var animationCard = false
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "Sponge", withExtension: "m4a") {
        
            try! player = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
            player.numberOfLoops = -1 /// Number of times to loop the audio
            //self.audioPlayer?.play() /// start playing
            
            return player
                        
        } else {
                print("No audio file found")
        }
        
        return nil
        
    }()
        
    
    public init(_ step: Binding<Int>){
        self._step = step
    }
    
    public var body: some View{
        
        ZStack{
            Image(uiImage: UIImage(named: "Intro.png")!)
                .resizable()
                .scaledToFill()
                .opacity(1)
                .onAppear {
                    audioPlayer?.play()
                }
                
            
            
            if(page == 1){
                VStack{
                   
                        
                
                    Button(action: {
                        page = 2
                    }, label: {
                        Text("Tap to know what happened...")
                            .font(.system(size: 28, weight: .bold, design: .rounded))
                            .foregroundColor(Color.white)
                            
                            .onAppear(){
                                withAnimation(Animation.easeInOut(duration: 1)
                                                .repeatForever()){
                                    fadeInOut.toggle()
                                }
                            }.opacity(fadeInOut ? 0 : 2)
                            
                    }).offset(y:200)
                }
            }
            if(page == 2){
                ZStack{
                    RoundedRectangle(cornerRadius: 50)
                        .fill(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                    
                    RoundedRectangle(cornerRadius: 50)
                        .strokeBorder(LinearGradient(
                            gradient: Gradient(stops: [
                                .init(color: Color(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1)), location: 0),
                                .init(color: Color(#colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)), location: 1)]),
                            startPoint: UnitPoint(x: 0.5, y: -3.0616171314629196e-17),
                            endPoint: UnitPoint(x: 0.5, y: 0.9999999999999999)), lineWidth: 3)
                    
                    if(introText == 1){
                        Text("🐠Anywhere in     the sea...🐟")
                            .foregroundColor(Color.black)
                            .font(.system(size: 40, weight: .bold, design: .default))
                    }
                    Button(action: {
                        step += 1
                    }, label: {
                        Image(uiImage: UIImage(named: "Conchiglia.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 60, height: 60)
                    })
                        .offset(x:165,y:90)
                }
                .frame(width: animationCard ? 375 : 2, height: animationCard ? 204.64 : 2)
                .animation(.interactiveSpring(response: 1, dampingFraction: 1, blendDuration: 10))
                .onAppear {
                    animationCard = true
                }
            }
           
        }
        .frame(width: 700, height: 490)
        
    }
}
