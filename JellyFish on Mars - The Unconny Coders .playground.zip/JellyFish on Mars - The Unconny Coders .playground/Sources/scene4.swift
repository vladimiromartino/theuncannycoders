import SwiftUI
import AVFoundation
import PlaygroundSupport


public struct scene4: View{
    @Binding var step: Int
    @State var introText = 1
    @State var animationCard = false
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "Scena bottiglie", withExtension: "mp3") {
        
            try! player = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
            player.numberOfLoops = -1 /// Number of times to loop the audio
            //self.audioPlayer?.play() /// start playing
            
            return player
                        
        } else {
                print("No audio file found")
        }
        
        return nil
        
    }()
        
    
    public init(_ step: Binding<Int>){
        self._step = step
    }
    
    public var body: some View{
        ZStack{
            Image(uiImage: UIImage(named: "Scena4.png")!)
                .resizable()
                .scaledToFill()
                .onAppear {
                    audioPlayer?.play()
                }
            //                .frame(width: 490, height: 700)
            ZStack{
                
                RoundedRectangle(cornerRadius: 50)
                    .fill(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                    .offset(x:-20, y:-180)
                
                RoundedRectangle(cornerRadius: 50)
                    .strokeBorder(LinearGradient(
                        gradient: Gradient(stops: [
                            .init(color: Color(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1)), location: 0),
                            .init(color: Color(#colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)), location: 1)]),
                        startPoint: UnitPoint(x: 0.5, y: -3.0616171314629196e-17),
                        endPoint: UnitPoint(x: 0.5, y: 0.9999999999999999)), lineWidth: 3)
                    .offset(x:-20, y:-180)
                
                if(introText == 1){
                    VStack{
                        
                        Text("Jelly has got an idea! (Ping💡) Jelly remembered about a biology lesson: “Jellyfish can clone themselves”. So he decided to split himself into three parts to be allowed to board the plane.")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                        
                    }
                    .offset(x:-20, y:-180)
                }else if(introText == 2){
                    VStack{
                        
                        Text("  Jelly is so smart!")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                            .font(.system(size: 40, weight: .bold, design: .default))
                    }
                    .offset(x:-20, y:-180)
                             
                }else if(introText == 3){
                    VStack{
                        
                        Text("  Jelly 1 is so happy! ")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                            .font(.system(size: 40, weight: .bold, design: .default))
                    }
                    .offset(x:-20, y:-180)
                            
                        }else if(introText == 4){
                            VStack{
                                
                                Text("  Jelly 2 is so happy! ")
                                    .foregroundColor(Color.black)
                                    .frame(width: 380)
                                    .font(.system(size: 40, weight: .bold, design: .default))
                            }
                            .offset(x:-20, y:-180)
                            
                        }else{
                    VStack{
                        
                        Text("  Jelly 3 is so happy!")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                            .font(.system(size: 40, weight: .bold, design: .default))
                    }
                    .offset(x:-20, y:-180)
                }
                
                Button(action: {
                    if(introText < 5){
                        introText += 1
                    }
                    else{
                        step += 1
                    }
                }, label: {
                    Image(uiImage: UIImage(named: "Conchiglia.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                })
                    .offset(x:190,y:-140)
            }
            .frame(width: animationCard ? 450 : 2, height: animationCard ? 120 : 2)
            .animation(.interactiveSpring(response: 1, dampingFraction: 1, blendDuration: 10))
            .onAppear {
                animationCard = true
            }
        }
        .frame(width:700,height:490)
    }
}
