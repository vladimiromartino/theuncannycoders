import SwiftUI
import AVFoundation
import PlaygroundSupport



public struct scene1: View{
    @Binding var step: Int
    @State var introText = 1
    @State var animationCard = false
    @State private var fadeInOut = false
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "GameOver", withExtension: "m4a") {
        
            try! player = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
            player.numberOfLoops = -1 /// Number of times to loop the audio
            //self.audioPlayer?.play() /// start playing
            
            return player
                        
        } else {
                print("No audio file found")
        }
        
        return nil
        
    }()
        
    
    public init(_ step: Binding<Int>){
        self._step = step
    }
    
    public var body: some View{
        ZStack{
            Image(uiImage: #imageLiteral(resourceName: "Scena1.png"))
                .resizable()
                .aspectRatio(contentMode: .fill)
                .onAppear {
                    audioPlayer?.play()
                }

            Image(uiImage: #imageLiteral(resourceName: "Stelline.png"))
                .resizable()
                .offset(x: 50, y: -50)
                .padding()
                .frame(width: 150, height: 150, alignment: .bottom)
                .onAppear(){
                    withAnimation(Animation.easeInOut(duration: 0.5)
                                    .repeatForever()){
                        fadeInOut.toggle()
                    }
                }.opacity(fadeInOut ? 0 : 2)
               
            
            

            ZStack{
                
                RoundedRectangle(cornerRadius: 50)
                    .fill(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                    .offset(x:150, y:180)
                
                RoundedRectangle(cornerRadius: 50)
                    .strokeBorder(LinearGradient(
                        gradient: Gradient(stops: [
                            .init(color: Color(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1)), location: 0),
                            .init(color: Color(#colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)), location: 1)]),
                        startPoint: UnitPoint(x: 0.5, y: -1),
                        endPoint: UnitPoint(x: 0.5, y: 1)), lineWidth: 3)
                    .offset(x:150, y:180)
                
                
                
                if(introText == 1){
                    VStack{
                        
                        Text("BabyJelly wishes to become an astronaut, but DaddyJelly would like him to go to the biggest aquarium in the world...")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                    
                    }
                    .offset(x:150, y:180)
                }else{
                    VStack{
                        
                        Text("BabyJelly is so sad!")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                            .font(.system(size: 40, weight: .bold, design: .default))
                    }
                    .offset(x:150, y:180)
                }
                
                Button(action: {
                    if(introText < 2){
                        introText += 1
                    }
                    else{
                        step += 1
                    }
                }, label: {
                    Image(uiImage: UIImage(named: "Conchiglia.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                })
                    .offset(x:320,y:220)
            }
            .frame(width: animationCard ? 300 : 2, height: animationCard ? 104.64 : 2)
            .animation(.interactiveSpring(response: 1, dampingFraction: 1, blendDuration: 10))
            .onAppear {
                animationCard = true
            }
        }
        
        .frame(width:700,height:490)
    }
}
