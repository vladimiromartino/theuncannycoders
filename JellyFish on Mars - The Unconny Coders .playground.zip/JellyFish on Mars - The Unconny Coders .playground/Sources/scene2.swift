import SwiftUI
import AVFoundation
import PlaygroundSupport


public struct scene2: View{
    @Binding var step: Int
    @State var introText = 1
    @State var animationCard = false
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "Stanza", withExtension: "m4a") {
        
            try! player = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
            player.numberOfLoops = -1 /// Number of times to loop the audio
            //self.audioPlayer?.play() /// start playing
            
            return player
                        
        } else {
                print("No audio file found")
        }
        
        return nil
        
    }()
        
    
    public init(_ step: Binding<Int>){
        self._step = step
    }
    
    public var body: some View{
        ZStack{
            Image(uiImage: UIImage(named: "Scena2.png")!)
                .resizable()
                .scaledToFill()
                .onAppear {
                    audioPlayer?.play()
                }
            //                .frame(width: 490, height: 700)
            ZStack{
                
                RoundedRectangle(cornerRadius: 50)
                    .fill(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                    .offset(x:-30, y:-180)
                
                RoundedRectangle(cornerRadius: 50)
                    .strokeBorder(LinearGradient(
                        gradient: Gradient(stops: [
                            .init(color: Color(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1)), location: 0),
                            .init(color: Color(#colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)), location: 1)]),
                        startPoint: UnitPoint(x: 0.5, y: -1),
                        endPoint: UnitPoint(x: 0.5, y: 1)), lineWidth: 3)
                    .offset(x:-30, y:-180)
                
                if(introText == 1){
                    VStack{
                        
                        Text("One day Jelly was reading the newspapers, and he read that there was water on Mars and Elon Musk allowed people to go with him.")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                    
                    }
                    .offset(x:-30, y:-180)
                }else{
                    VStack{
                        
                        Text("Jelly is so excited!")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                            .font(.system(size: 35, weight: .bold, design: .default))
                    }
                    .offset(x:-30, y:-180)
                }
                
                Button(action: {
                    if(introText < 2){
                        introText += 1
                    }
                    else{
                        step += 1
                    }
                }, label: {
                    Image(uiImage: UIImage(named: "Conchiglia.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                })
                    .offset(x:150,y:-140)
            }
            .frame(width: animationCard ? 400 : 2, height: animationCard ? 104.64 : 2)
            .animation(.interactiveSpring(response: 1, dampingFraction: 1, blendDuration: 10))
            .onAppear {
                animationCard = true
            }
        }
        .frame(width:700,height:490)
    }
}
