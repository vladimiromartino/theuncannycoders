import SwiftUI

public struct controller: View {
    @State var step = 0
//    @State var tasks = 0
    
    public init() {}
    
    public var body: some View {
        if(step == 0) {
            intro($step)
        }
        else if(step == 1){
            scene1($step)
        }
        else if(step == 2){
            scene2($step)
        }
        else if(step == 3){
            scene3($step)
        }
        else if(step == 4){
            scene4($step)
        }
        else if(step == 5){
            scene5($step)
        }
        else if(step == 6){
           scene6($step)
        }
        else{
//           scena7($step)
        }
    }
}

