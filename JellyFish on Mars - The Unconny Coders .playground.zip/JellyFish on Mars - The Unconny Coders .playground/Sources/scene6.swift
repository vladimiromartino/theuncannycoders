import SwiftUI
import AVFoundation
import PlaygroundSupport


public struct scene6: View{
    @Binding var step: Int
    @State var introText = 1
    @State var animationCard = false
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "Finale", withExtension: "m4a") {
        
            try! player = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
            player.numberOfLoops = -1 /// Number of times to loop the audio
            //self.audioPlayer?.play() /// start playing
            
            return player
                        
        } else {
                print("No audio file found")
        }
        
        return nil
        
    }()
        
    
    public init(_ step: Binding<Int>){
        self._step = step
    }
    public var body: some View{
        
        ZStack{
            Image(uiImage: UIImage(named: "ScenaFinale.png")!)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .onAppear {
                    audioPlayer?.play()
                }
        }.frame(width:700,height:490)
    }
    
}
