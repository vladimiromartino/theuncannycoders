import SwiftUI
import AVFoundation
import PlaygroundSupport


public struct scene5: View{
    @Binding var step: Int
    @State var introText = 1
    @State var animationCard = false
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "Spazio", withExtension: "m4a") {
        
            try! player = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
            player.numberOfLoops = -1 /// Number of times to loop the audio
            //self.audioPlayer?.play() /// start playing
            
            return player
                        
        } else {
                print("No audio file found")
        }
        
        return nil
        
    }()
        
    
    public init(_ step: Binding<Int>){
        self._step = step
    }
    
    public var body: some View{
        ZStack{
            Image(uiImage: UIImage(named: "Scena5.png")!)
                .resizable()
                .scaledToFill()
                .onAppear {
                    audioPlayer?.play()
                }
            
            ZStack{
                
                RoundedRectangle(cornerRadius: 50)
                    .fill(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                    .offset(y:180)
                
                RoundedRectangle(cornerRadius: 50)
                    .strokeBorder(LinearGradient(
                        gradient: Gradient(stops: [
                            .init(color: Color(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1)), location: 0),
                            .init(color: Color(#colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)), location: 1)]),
                        startPoint: UnitPoint(x: 0.5, y: -3.0616171314629196e-17),
                        endPoint: UnitPoint(x: 0.5, y: 0.9999999999999999)), lineWidth: 3)
                    .offset(y:180)
                
                if(introText == 1){
                    VStack{
                        
                        Text("Jelly arrived on Mars and he had made a family in a puddle of water with the other parts of himself.")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                        
                    }
                    .offset(y:180)
                }else if(introText == 2){
                    VStack{
                        
                        Text("Now Jelly works with the astronauts to discover the new planet.")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                    }
                    .offset(y:180)
                             
                }else if(introText == 3){
                    VStack{
                        
                        Text("OldJelly feels totally accomplished. ")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                    }
                    .offset(y:180)
                            
                        }else{
                    VStack{
                        
                        Text("   They all lived happily ever after!♥        ")
                            .foregroundColor(Color.black)
                            .frame(width: 380)
                            .font(.system(size: 40, weight: .bold, design: .default))
                    }
                    .offset(y:180)
                }
                
                Button(action: {
                    if(introText < 4){
                        introText += 1
                    }
                    else{
                        step += 1
                    }
                }, label: {
                    Image(uiImage: UIImage(named: "Conchiglia.png")!)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                })
                    .offset(x:200,y:220)
            }
            .frame(width: animationCard ? 450 : 2, height: animationCard ? 104.64 : 2)
            .animation(.interactiveSpring(response: 1, dampingFraction: 1, blendDuration: 10))
            .onAppear {
                animationCard = true
            }
        }
        .frame(width:700,height:490)
    }
}
